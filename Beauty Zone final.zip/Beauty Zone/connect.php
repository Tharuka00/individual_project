<?php
    $yourName = $_POST['yourName'];
    $yourEmail = $_POST['yourEmail'];
    $subject = $_POST['subject'];
    $message = $_POST['message'];

    //database connection
    $conn = new mysqli('localhost','root','','beauty_zone');
    if($conn->connect_error){
        die('Connection Failed : '.$conn->connect_error);
    }else{
        $stmt = $conn->prepare("insert into apoinment(yourName , yourEmail , subject , message)
        values(?,?,?,?)");
        $stmt->bind_param("ssss",$yourName, $yourEmail, $subject, $message);
        $stmt->execute();
        echo "Send Successfully";
        $stmt->close();
        $conn->close();
    }
?>