<?php 
    $con = mysqli_connect('')
?>